import { Component, OnDestroy, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Config, LogItem, LogPage, Run, RunSummary } from './models';
import { isActive, nextLogCursor, progressPercent, safeExternalUrl, shouldPoll } from './run-state';
import { RunFilesComponent } from './run-files';
import { QwenStatusComponent } from './qwen-status';

@Component({ selector: 'app-root', standalone: true, imports: [CommonModule, FormsModule, MatButtonModule, MatFormFieldModule, MatInputModule, MatProgressBarModule, MatTooltipModule, RunFilesComponent, QwenStatusComponent], templateUrl: './app.html' })
export class AppComponent implements OnInit, OnDestroy {
  readonly runs = signal<RunSummary[]>([]);
  readonly run = signal<Run | null>(null);
  readonly config = signal<Config | null>(null);
  readonly logs = signal<LogItem[]>([]);
  readonly loading = signal(true);
  readonly detailLoading = signal(false);
  readonly submitting = signal(false);
  readonly error = signal('');
  readonly detailError = signal('');
  readonly logError = signal('');
  readonly configError = signal('');
  readonly downloadError = signal('');
  readonly downloading = signal(false);
  readonly selectedId = signal<string | null>(null);
  readonly tab = signal<'progress' | 'result' | 'files' | 'task'>('progress');
  readonly fileCount = signal(0);
  readonly lastUpdated = signal<Date | null>(null);
  requirements = '';
  readonly stageNames: Record<string, string> = { analysis: 'Анализ требований', design: 'Проектирование', generation: 'Генерация кода', build: 'Сборка', test: 'Тестирование', security: 'Аудит', deploy: 'Развертывание', documentation: 'Документация' };
  readonly stageDescriptions: Record<string, string> = { analysis: 'Задача, сценарии и ограничения', design: 'Архитектура и модель данных', generation: 'Код приложения по требованиям', build: 'Проверка компиляции проекта', test: 'Проверка рабочих сценариев', security: 'Зависимости и информационные находки', deploy: 'Запуск приложения в Docker', documentation: 'Инструкции и итоговые отчеты' };
  readonly labels: Record<string, string> = { queued: 'В очереди', running: 'В работе', succeeded: 'Готово', failed: 'Ошибка', blocked: 'Требуется внимание', interrupted: 'Прерван', pending: 'Ожидает', passed: 'Пройдено', not_run: 'Не выполнялось' };
  readonly isActive = isActive;
  readonly safeUrl = safeExternalUrl;
  readonly progress = progressPercent;
  private timer?: ReturnType<typeof setTimeout>;
  private epoch = 0;
  private cursor = 0;
  private destroyed = false;
  private refreshing = false;

  async ngOnInit(): Promise<void> {
    const selected = new URL(location.href).searchParams.get('run');
    await Promise.allSettled([this.loadConfig(), this.loadList(), selected ? this.selectRun(selected) : Promise.resolve()]);
    this.loading.set(false);
    this.schedule();
  }
  ngOnDestroy(): void { this.destroyed = true; this.epoch++; clearTimeout(this.timer); }
  label(status: string): string { return this.labels[status] || status; }
  stageName(id: string): string { return this.stageNames[id] || id; }
  title(text: string): string { const line = text.trim().split('\n')[0]; return line.length > 92 ? line.slice(0, 92) + '…' : line; }
  shortId(id: string): string { return id.slice(0, 8); }
  activeCount(): number { return this.runs().filter(item => isActive(item.status)).length; }
  successCount(): number { return this.runs().filter(item => item.status === 'succeeded').length; }
  formatDuration(seconds: number): string { const value = Math.max(0, Math.round(seconds)); return value < 60 ? `${value} с` : `${Math.floor(value / 60)} мин ${value % 60} с`; }
  tokenCount(value: number | null | undefined): string { return value == null ? 'Нет данных' : value.toLocaleString('ru-RU'); }
  artifactUrl(artifactId: string): string { return `/api/runs/${encodeURIComponent(this.selectedId() || '')}/artifacts/${encodeURIComponent(artifactId)}`; }
  private async request<T>(url: string, init?: RequestInit): Promise<T> {
    const response = await fetch(url, init);
    if (!response.ok) {
      let message = `Сервис вернул ошибку ${response.status}`;
      try { const data = await response.json(); if (typeof data.detail === 'string') message = data.detail; } catch { /* Preserve status for non-JSON proxy errors. */ }
      throw new Error(message);
    }
    return response.json() as Promise<T>;
  }
  private message(error: unknown): string { return error instanceof TypeError ? 'Нет связи с API. Проверьте, что сервис запущен, и повторите попытку.' : error instanceof Error ? error.message : 'Не удалось выполнить запрос'; }
  async loadConfig(): Promise<void> {
    try { this.config.set(await this.request<Config>('/api/config')); this.configError.set(''); }
    catch (error) { this.configError.set(this.message(error)); }
  }
  async loadList(): Promise<void> {
    try { this.runs.set(await this.request<RunSummary[]>('/api/runs')); this.error.set(''); this.lastUpdated.set(new Date()); }
    catch (error) { this.error.set(this.message(error)); }
  }
  async refresh(): Promise<void> {
    if (this.refreshing) return;
    this.refreshing = true;
    try {
      const id = this.selectedId();
      await Promise.allSettled([this.loadList(), this.loadConfig(), id ? this.loadDetail(id, this.epoch) : Promise.resolve()]);
    } finally { this.refreshing = false; this.loading.set(false); this.schedule(); }
  }
  private schedule(): void {
    clearTimeout(this.timer);
    if (this.destroyed || (!shouldPoll(this.runs()) && !isActive(this.run()?.status || ''))) return;
    this.timer = setTimeout(() => { void this.refreshActive(); }, 3000);
  }
  private async refreshActive(): Promise<void> {
    if (this.refreshing) { this.schedule(); return; }
    this.refreshing = true;
    try {
      const id = this.selectedId();
      await Promise.allSettled([this.loadList(), id && isActive(this.run()?.status || '') ? this.loadDetail(id, this.epoch) : Promise.resolve()]);
    } finally { this.refreshing = false; this.schedule(); }
  }
  async selectRun(id: string): Promise<void> {
    const epoch = ++this.epoch;
    this.selectedId.set(id); this.run.set(null); this.logs.set([]); this.fileCount.set(0); this.cursor = 0;
    this.detailError.set(''); this.logError.set(''); this.downloadError.set(''); this.tab.set('progress'); this.detailLoading.set(true);
    const url = new URL(location.href); url.searchParams.set('run', id); history.replaceState({}, '', url);
    await this.loadDetail(id, epoch);
    if (epoch === this.epoch) { this.detailLoading.set(false); this.schedule(); }
  }
  private async loadDetail(id: string, epoch: number): Promise<void> {
    try {
      const value = await this.request<Run>(`/api/runs/${encodeURIComponent(id)}`);
      if (epoch !== this.epoch || this.destroyed) return;
      this.run.set(value); this.detailError.set('');
      await this.loadLogs(id, epoch);
    } catch (error) { if (epoch === this.epoch) this.detailError.set(this.message(error)); }
  }
  async retryLogs(): Promise<void> { const id = this.selectedId(); if (id) await this.loadLogs(id, this.epoch); }
  private async loadLogs(id: string, epoch: number): Promise<void> {
    try {
      // Drain through the empty page, including the terminal run's final partial page.
      while (epoch === this.epoch && !this.destroyed) {
        const page = await this.request<LogPage>(`/api/runs/${encodeURIComponent(id)}/logs?after=${this.cursor}`);
        if (epoch !== this.epoch || this.destroyed) return;
        const previous = this.cursor;
        this.cursor = nextLogCursor(previous, page);
        const fresh = page.items.filter(item => item.cursor > previous);
        this.logs.update(items => [...items, ...fresh].slice(-2000)); this.logError.set('');
        if (!page.items.length || this.cursor <= previous) return;
      }
    } catch (error) { if (epoch === this.epoch) this.logError.set(this.message(error)); }
  }
  newRun(): void {
    this.epoch++; this.selectedId.set(null); this.run.set(null); this.logs.set([]); this.detailError.set('');
    const url = new URL(location.href); url.searchParams.delete('run'); history.replaceState({}, '', url); this.schedule();
    setTimeout(() => document.getElementById('requirements')?.focus());
  }
  reuse(): void { const value = this.run(); if (value) { this.requirements = value.requirements; this.newRun(); } }
  async submit(): Promise<void> {
    if (this.submitting() || !this.requirements.trim() || this.requirements.length > 100000) return;
    this.submitting.set(true); this.error.set('');
    try {
      const result = await this.request<{ runId: string }>('/api/runs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ requirements: this.requirements }) });
      await Promise.allSettled([this.loadList(), this.selectRun(result.runId)]);
    } catch (error) { this.error.set(this.message(error)); }
    finally { this.submitting.set(false); this.schedule(); }
  }
  async download(): Promise<void> {
    const id = this.selectedId(); if (!id || this.downloading()) return;
    this.downloading.set(true); this.downloadError.set('');
    try {
      const response = await fetch(`/api/runs/${encodeURIComponent(id)}/download`);
      if (!response.ok) throw new Error(`Не удалось скачать архив (${response.status}). Попробуйте скачать файлы отдельно.`);
      const url = URL.createObjectURL(await response.blob());
      const anchor = document.createElement('a'); anchor.href = url; anchor.download = `run-${id}.zip`; anchor.click();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    } catch (error) { this.downloadError.set(this.message(error)); }
    finally { this.downloading.set(false); }
  }
}
