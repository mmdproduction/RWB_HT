import { bootstrapApplication } from '@angular/platform-browser';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { AppComponent } from './app';
bootstrapApplication(AppComponent, { providers: [provideAnimationsAsync()] }).catch(error => console.error('Не удалось открыть панель', error));
